@echo off
cd /d "%~dp0"

where python >nul 2>nul
if errorlevel 1 (
  echo Python 3 is required to run the J.A.R.V.I.S Local Bridge. Install Python 3, then try again.
  echo.
  pause
  exit /b 1
)

echo J.A.R.V.I.S Local Bridge is running at http://127.0.0.1:8787
echo Keep this Command Prompt window open while you use J.A.R.V.I.S.
echo.
python jarvis_local_bridge.py
echo.
pause
