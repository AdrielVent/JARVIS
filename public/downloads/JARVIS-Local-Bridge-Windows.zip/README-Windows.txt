J.A.R.V.I.S Local Bridge for Windows

This bridge runs only on your own Windows laptop at:
http://127.0.0.1:8787

How to use it:

1. Unzip the file.
2. Double-click start-jarvis-bridge.bat.
3. If Windows asks for permission, click Allow Access.
4. Keep the Command Prompt window open.
5. Return to:
   https://adrielvent.github.io/JARVIS/
6. Click Find My Bridge or enter:
   http://127.0.0.1:8787
7. Click Connect.

Your laptop details stay local. The public J.A.R.V.I.S website connects to this bridge running on your own computer.
