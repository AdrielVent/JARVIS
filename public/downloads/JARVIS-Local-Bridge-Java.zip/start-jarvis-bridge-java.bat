@echo off
cd /d "%~dp0"

where java >nul 2>nul
if errorlevel 1 (
  echo Java 11 or newer is required to run the J.A.R.V.I.S Java Local Bridge. Install a JDK, then try again.
  echo.
  pause
  exit /b 1
)

echo J.A.R.V.I.S Java Local Bridge is running at http://127.0.0.1:8787
echo Keep this Command Prompt window open while you use J.A.R.V.I.S.
echo.
java JarvisLocalBridge.java
echo.
pause
