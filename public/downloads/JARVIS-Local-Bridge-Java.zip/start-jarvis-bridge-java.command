#!/bin/bash
cd "$(dirname "$0")"

if ! command -v java >/dev/null 2>&1; then
  echo "Java 11 or newer is required to run the J.A.R.V.I.S Java Local Bridge. Install a JDK, then try again."
  echo
  read -r -p "Press Return to close this window."
  exit 1
fi

echo "J.A.R.V.I.S Java Local Bridge is running at http://127.0.0.1:8787"
echo "Keep this Terminal window open while you use J.A.R.V.I.S."
echo
java JarvisLocalBridge.java
echo
read -r -p "Bridge stopped. Press Return to close this window."
