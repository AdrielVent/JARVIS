J.A.R.V.I.S Local Bridge for Java

This package is cross-platform for macOS and Windows.
It runs a read-only localhost bridge on your own laptop at:
http://127.0.0.1:8787

Requirements:

- Java 11 or newer.

macOS:

1. Unzip the file.
2. Double-click start-jarvis-bridge-java.command.
3. If macOS blocks it, right-click the file and choose Open.
4. Keep the Terminal window open.

Windows:

1. Unzip the file.
2. Double-click start-jarvis-bridge-java.bat.
3. If Windows Firewall asks for permission, click Allow Access.
4. Keep the Command Prompt window open.

Then return to:
https://adrielvent.github.io/JARVIS/

Click Find My Bridge or enter:
http://127.0.0.1:8787

The Java bridge exposes only:
GET /status
GET /system-info

It does not scan your network, read files, upload data, or run arbitrary commands.
