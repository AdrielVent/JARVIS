@echo off
cd /d "%~dp0"

where powershell >nul 2>nul
if errorlevel 1 (
  echo Windows PowerShell is required to run this J.A.R.V.I.S Local Bridge.
  echo.
  pause
  exit /b 1
)

echo J.A.R.V.I.S PowerShell Local Bridge is running at http://127.0.0.1:8787
echo Keep this Command Prompt window open while you use J.A.R.V.I.S.
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0jarvis_local_bridge.ps1"
echo.
pause
