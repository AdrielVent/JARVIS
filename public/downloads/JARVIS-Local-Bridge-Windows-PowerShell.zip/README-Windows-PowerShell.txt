J.A.R.V.I.S Local Bridge for Windows PowerShell

This package does not require Python.
It runs a read-only localhost bridge on your own Windows laptop at:
http://127.0.0.1:8787

How to use it:

1. Unzip the file.
2. Double-click start-jarvis-bridge-powershell.bat.
3. If Windows Firewall asks for permission, click Allow Access.
4. Keep the Command Prompt window open.
5. Return to:
   https://adrielvent.github.io/JARVIS/
6. Click Find My Bridge or enter:
   http://127.0.0.1:8787
7. Click Connect.

The PowerShell bridge exposes only:
GET /status
GET /system-info

It does not scan your network, read files, upload data, or run arbitrary commands.
