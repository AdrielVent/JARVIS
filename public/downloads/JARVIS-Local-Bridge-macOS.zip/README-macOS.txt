J.A.R.V.I.S Local Bridge for macOS

This bridge runs only on your own Mac at:
http://127.0.0.1:8787

Recommended path:

1. Unzip the file.
2. Double-click start-jarvis-bridge.command.
3. If macOS blocks it, right-click the file and choose Open.
4. Keep the Terminal window open.
5. Return to:
   https://adrielvent.github.io/JARVIS/
6. Click Find My Bridge or enter:
   http://127.0.0.1:8787
7. Click Connect.

Alternative Java path:

1. Install Java 11 or newer.
2. Double-click start-jarvis-bridge-java.command.
3. Keep the Terminal window open.
4. Return to J.A.R.V.I.S and connect to:
   http://127.0.0.1:8787

Your laptop details stay local. The public J.A.R.V.I.S website connects to this bridge running on your own Mac.
