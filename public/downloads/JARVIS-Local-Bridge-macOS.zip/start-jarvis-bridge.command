#!/bin/bash
cd "$(dirname "$0")"

if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3 is required to run the J.A.R.V.I.S Local Bridge. Install Python 3, then try again."
  echo
  read -r -p "Press Return to close this window."
  exit 1
fi

echo "J.A.R.V.I.S Local Bridge is running at http://127.0.0.1:8787"
echo "Keep this Terminal window open while you use J.A.R.V.I.S."
echo
python3 jarvis_local_bridge.py
echo
read -r -p "Bridge stopped. Press Return to close this window."
